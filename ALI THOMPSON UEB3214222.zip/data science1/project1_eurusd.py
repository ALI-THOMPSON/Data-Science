import yfinance as yf
import pandas as pd

# Define currency pair and date range
symbol = "EURUSD=X"
start_date = "2000-01-01"
end_date = "2025-01-01"

# Download historical data
data = yf.download(symbol, start=start_date, end=end_date)

# Display first 10 rows
print(data.head(10))

# Save data to CSV file
data.to_csv("EUR_USD_2000_2025.csv")